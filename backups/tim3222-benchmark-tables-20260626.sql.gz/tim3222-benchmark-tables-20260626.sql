-- TIM-2447: Seed benchmark_metrics catalog.
--
-- One row per metric we benchmark. Pillars 1-4 are Phase 0 ship target.
-- Pillars 5-8 are seeded so the catalog is complete even before extraction
-- runs land data for them (avoids a metric-key mismatch when later phases
-- run their first extraction). Idempotent.

INSERT INTO public.benchmark_metrics (metric_key, pillar, name, unit, direction_of_better, description) VALUES
  -- Pillar 1: Revenue & traffic
  ('auv_usd',                       'revenue_traffic',     'Average unit volume (annual revenue per location)', 'usd_year',     'higher', 'Annual revenue per shop. The single highest-signal revenue metric.'),
  ('avg_ticket_usd',                'revenue_traffic',     'Average ticket size',                                'usd',          'higher', 'Average $ per transaction.'),
  ('transactions_per_day',          'revenue_traffic',     'Transactions per day',                               'count_day',    'higher', 'Daily transaction count (covers).'),
  ('revenue_per_sqft_usd',          'revenue_traffic',     'Revenue per square foot (annual)',                  'usd_sqft_year','higher', 'Annual revenue divided by built area.'),
  ('transactions_per_hour',         'revenue_traffic',     'Transactions per hour',                              'count_hour',   'higher', 'Throughput at peak / average hour.'),

  -- Pillar 2: COGS
  ('total_cogs_pct',                'cogs',                'Total cost of goods sold (% of revenue)',            'pct',          'lower',  'All COGS including beverage and food.'),
  ('beverage_cogs_pct',             'cogs',                'Beverage COGS (% of beverage revenue)',              'pct',          'lower',  'Coffee + milk + syrups + cups for beverage sales only.'),
  ('food_cogs_pct',                 'cogs',                'Food COGS (% of food revenue)',                      'pct',          'lower',  'Food and pastry ingredients only.'),
  ('waste_pct',                     'cogs',                'Waste (% of inputs)',                                'pct',          'lower',  'Spoilage / pulled-shot / dumped-milk percentage.'),

  -- Pillar 3: Labor
  ('labor_pct_of_revenue',          'labor',               'Labor cost (% of revenue)',                          'pct',          'lower',  'All wages + payroll taxes / total revenue.'),
  ('sales_per_labor_hour_usd',      'labor',               'Sales per labor hour',                               'usd_hour',     'higher', 'Revenue divided by total worked hours.'),
  ('turnover_pct_annual',           'labor',               'Staff turnover (% annual)',                          'pct',          'lower',  'Annualized rolling turnover.'),
  ('wage_rate_usd_hour',            'labor',               'Average wage rate',                                  'usd_hour',     'range',  'Average baseline wage rate (pre-tip).'),

  -- Pillar 4: Real estate & fitout
  ('rent_pct_of_revenue',           'real_estate_fitout',  'Rent (% of revenue)',                                'pct',          'lower',  'Base rent + CAM as % of revenue.'),
  ('rent_per_sqft_annual_usd',      'real_estate_fitout',  'Rent per square foot (annual)',                      'usd_sqft_year','range',  'Annual base rent per sqft.'),
  ('fitout_per_sqft_usd',           'real_estate_fitout',  'Fit-out cost per square foot',                       'usd_sqft',     'lower',  'Total fit-out capex divided by sqft.'),
  ('lease_term_years',              'real_estate_fitout',  'Lease term (years)',                                 'years',        'range',  'Initial term length.'),

  -- Pillar 5: Equipment & throughput (catalog only, Phase 0 doesn't extract these)
  ('equipment_capex_per_auv_pct',   'equipment_throughput', 'Equipment capex / AUV',                              'pct',          'lower',  'Total equipment spend as a % of expected first-year AUV.'),
  ('group_heads_per_peak_tx',       'equipment_throughput', 'Espresso group heads per peak hourly transactions',  'count',        'range',  'Throughput sizing of the espresso bar.'),

  -- Pillar 6: Menu & pricing (overlaps with TIM-1698 industry-benchmarks.ts)
  ('avg_drink_price_usd',           'menu_pricing',         'Average drink price',                                'usd',          'range',  'Mean price across drink menu.'),
  ('attach_rate_food_pct',          'menu_pricing',         'Food attach rate',                                    'pct',          'higher', 'Percentage of orders that include a food item.'),
  ('discount_pct',                  'menu_pricing',         'Discount / promo (% of revenue)',                    'pct',          'lower',  'Discounts as a share of gross revenue.'),

  -- Pillar 7: Marketing & loyalty
  ('cac_usd',                       'marketing_loyalty',    'Customer acquisition cost',                          'usd',          'lower',  'Total marketing spend / new customers acquired.'),
  ('repeat_visit_rate_pct',         'marketing_loyalty',    'Repeat visit rate (% within 30d)',                   'pct',          'higher', 'Share of customers who return within 30 days.'),
  ('loyalty_enrollment_pct',        'marketing_loyalty',    'Loyalty enrollment (% of customers)',                'pct',          'higher', 'Customers signed up for the loyalty program.'),
  ('google_rating_avg',             'marketing_loyalty',    'Google rating (average)',                            'rating_5',     'higher', 'Mean Google rating across reviews.'),

  -- Pillar 8: Customer experience
  ('wait_time_seconds',             'customer_experience',  'Wait time (seconds, order-to-handoff)',              'seconds',      'lower',  'Time from order placed to drink in hand.'),
  ('complaint_rate_pct',            'customer_experience',  'Complaint rate (% of transactions)',                 'pct',          'lower',  'Logged complaints / total transactions.')
ON CONFLICT (metric_key) DO UPDATE SET
  pillar = EXCLUDED.pillar,
  name = EXCLUDED.name,
  unit = EXCLUDED.unit,
  direction_of_better = EXCLUDED.direction_of_better,
  description = EXCLUDED.description;
-- TIM-2447: Seed benchmark_cohorts.
--
-- Starter cohort set covering the most common slices a Groundwork user will
-- fall into. The Phase 1 cohort matcher (separate issue) does nearest-neighbor
-- on (model + sqft_bucket + auv_tier + geo_tier); these cover the high-signal
-- combinations. Extra cohorts can be added later without a migration — this
-- seed is idempotent on cohort_key.
--
-- axes shape: { model, sqft_bucket, geo_tier, age_bucket, auv_tier, concept }
--   model        ∈ {drive_thru, cafe, kiosk, cafe_drive_thru, multi_location, mobile_cart}
--   sqft_bucket  ∈ {lt_500, 500_1500, 1500_3000, gt_3000}
--   geo_tier     ∈ {top_50_metro, mid_metro, small_metro, rural}
--   age_bucket   ∈ {pre_open, lt_1y, 1_3y, 3_7y, mature_7plus}
--   auv_tier     ∈ {low, mid, high, top_decile}
--   concept      ∈ {third_wave_specialty, neighborhood_cafe, grab_and_go, cafe_food_program, roastery_cafe}

INSERT INTO public.benchmark_cohorts (cohort_key, axes, description) VALUES
  (
    'drive_thru_500_1500_top50_1_3y',
    '{"model":"drive_thru","sqft_bucket":"500_1500","geo_tier":"top_50_metro","age_bucket":"1_3y"}'::jsonb,
    'Drive-thru, 500-1500 sqft, top-50 metro, 1-3 years old.'
  ),
  (
    'cafe_500_1500_top50_1_3y',
    '{"model":"cafe","sqft_bucket":"500_1500","geo_tier":"top_50_metro","age_bucket":"1_3y"}'::jsonb,
    'Dine-in cafe, 500-1500 sqft, top-50 metro, 1-3 years old.'
  ),
  (
    'cafe_third_wave_neighborhood',
    '{"model":"cafe","concept":"third_wave_specialty"}'::jsonb,
    'Third-wave specialty cafe, neighborhood (model and concept only — broad).'
  ),
  (
    'kiosk_small',
    '{"model":"kiosk","sqft_bucket":"lt_500"}'::jsonb,
    'Kiosk under 500 sqft, any region.'
  ),
  (
    'cafe_food_program_1500_3000',
    '{"model":"cafe","sqft_bucket":"1500_3000","concept":"cafe_food_program"}'::jsonb,
    'Cafe with food program, 1500-3000 sqft.'
  ),
  (
    'multi_location_chain',
    '{"model":"multi_location"}'::jsonb,
    'Multi-location operators (3+ shops); upper-bound reference cohort from SEC filings.'
  )
ON CONFLICT (cohort_key) DO UPDATE SET
  axes = EXCLUDED.axes,
  description = EXCLUDED.description;
-- TIM-2447: Static seed for benchmark_reference_values.
--
-- The AI-extraction pipeline (scripts/run-benchmark-extraction.mjs) is the
-- canonical mechanism for refreshing this table — it lands 3-5 rows per run on
-- the first pass. To meet Phase 0's acceptance criterion (>=1 row per headline
-- metric across pillars 1-4) on day one, we also pre-seed a baseline from
-- well-known public sources: SEC EDGAR (Starbucks / Dutch Bros 10-K filings),
-- BLS OEWS wage data, NCA NCDT, NRA published guidelines, and Daily Coffee
-- News trade press. Every row is source-cited; the unique constraint
-- (metric_id, cohort_id, source_url, extraction_date) means subsequent LLM
-- extractions on the same source same-day overwrite, and quarterly re-runs
-- land new dated rows.
--
-- Dataset version 2026.Q2.

INSERT INTO public.benchmark_reference_values (
  metric_id, cohort_id, value_type, p25, p50, p75, low, high, sample_size,
  source_url, source_name, source_publication_date, extraction_date,
  extraction_confidence, dataset_version, notes
) VALUES
  -- ── Pillar 1: Revenue & traffic ──────────────────────────────────────────
  -- AUV — multi-location chain reference (upper bound), Starbucks system AUV from 10-K.
  (
    'auv_usd',
    (SELECT id FROM public.benchmark_cohorts WHERE cohort_key = 'multi_location_chain'),
    'range', NULL, NULL, NULL, 1500000, 1700000, NULL,
    'https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=0000829224&type=10-K',
    'SEC EDGAR — Starbucks 10-K (FY2024)',
    '2024-11-15', '2026-06-07', 'high', '2026.Q2',
    'Starbucks company-operated US store AUV per 10-K segment disclosure. Upper-bound reference; independent specialty cafes typically run 30-60% of this.'
  ),
  -- AUV — independent specialty cafe range, NCA + trade-press composite.
  (
    'auv_usd', NULL,
    'range', NULL, NULL, NULL, 400000, 1200000, NULL,
    'https://www.ncausa.org/Industry-Resources',
    'National Coffee Association — Industry Resources + trade-press composite',
    '2024-01-01', '2026-06-07', 'medium', '2026.Q2',
    'Independent specialty cafe AUV range; lower bound = sub-scale grab-and-go, upper bound = high-traffic third-wave with food.'
  ),
  -- Average ticket — independent specialty range, NCA NCDT 2024.
  (
    'avg_ticket_usd', NULL,
    'range', NULL, NULL, NULL, 6.50, 12.50, NULL,
    'https://www.ncausa.org/Industry-Resources',
    'National Coffee Association — NCDT 2024',
    '2024-01-01', '2026-06-07', 'high', '2026.Q2',
    'NCA National Coffee Data Trends 2024: average ticket at independent specialty cafes (drink + food attach).'
  ),
  -- Transactions per day — independent cafe range, trade-press composite.
  (
    'transactions_per_day', NULL,
    'range', NULL, NULL, NULL, 150, 600, NULL,
    'https://dailycoffeenews.com/category/business/',
    'Daily Coffee News — Operator profiles 2023-2024',
    '2024-01-01', '2026-06-07', 'medium', '2026.Q2',
    'Trade-press operator profiles: low end = small neighborhood cafe, high end = high-traffic drive-thru or 1500+ sqft third-wave.'
  ),
  -- Revenue per sqft — independent specialty range.
  (
    'revenue_per_sqft_usd', NULL,
    'range', NULL, NULL, NULL, 400, 900, NULL,
    'https://dailycoffeenews.com/category/business/',
    'Daily Coffee News — Trade-press composite',
    '2024-01-01', '2026-06-07', 'medium', '2026.Q2',
    'Annual revenue per built sqft for independent specialty cafes. Drive-thru small format runs higher per sqft than cafe formats.'
  ),

  -- ── Pillar 2: COGS ───────────────────────────────────────────────────────
  -- Total COGS — NCA + NRA published target range.
  (
    'total_cogs_pct', NULL,
    'range', NULL, NULL, NULL, 28, 35, NULL,
    'https://www.ncausa.org/Industry-Resources',
    'National Coffee Association — Industry Resources',
    '2024-01-01', '2026-06-07', 'high', '2026.Q2',
    'NCA / NRA target range for total COGS at specialty coffee operations.'
  ),
  -- Beverage COGS — NCA-aligned operator data.
  (
    'beverage_cogs_pct', NULL,
    'range', NULL, NULL, NULL, 18, 25, NULL,
    'https://www.ncausa.org/Industry-Resources',
    'National Coffee Association — Industry Resources',
    '2024-01-01', '2026-06-07', 'high', '2026.Q2',
    'Beverage-only COGS for specialty espresso operations.'
  ),
  -- Food COGS — NRA limited-service food guideline.
  (
    'food_cogs_pct', NULL,
    'range', NULL, NULL, NULL, 28, 36, NULL,
    'https://restaurant.org/research-and-media/research/industry-statistics/',
    'National Restaurant Association — Industry Statistics',
    '2024-01-01', '2026-06-07', 'high', '2026.Q2',
    'NRA food cost guideline for limited-service cafe food programs (pastries, sandwiches, salads).'
  ),

  -- ── Pillar 3: Labor ──────────────────────────────────────────────────────
  -- Labor % of revenue — independent specialty (the multi-location chain row from LLM stays alongside this).
  (
    'labor_pct_of_revenue', NULL,
    'range', NULL, NULL, NULL, 28, 35, NULL,
    'https://sca.coffee/research',
    'Specialty Coffee Association — Operators Guide',
    '2024-01-01', '2026-06-07', 'high', '2026.Q2',
    'SCA Operators Guide observed range for independent specialty cafes; SCA target band is 25-30%.'
  ),
  -- Sales per labor hour — independent specialty.
  (
    'sales_per_labor_hour_usd', NULL,
    'range', NULL, NULL, NULL, 70, 130, NULL,
    'https://sca.coffee/research',
    'Specialty Coffee Association — Operators Guide',
    '2024-01-01', '2026-06-07', 'medium', '2026.Q2',
    'Sales per scheduled labor hour at independent specialty cafes; varies sharply with daypart mix and AUV.'
  ),
  -- Turnover — full BLS limited-service range (broader than the LLM-extracted MRM row at 75-80).
  (
    'turnover_pct_annual', NULL,
    'range', NULL, NULL, NULL, 60, 130, NULL,
    'https://restaurant.org/research-and-media/research/industry-statistics/',
    'National Restaurant Association — Industry Statistics',
    '2024-01-01', '2026-06-07', 'high', '2026.Q2',
    'NRA limited-service turnover range; specialty cafes that invest in benefits + training cluster at the lower end.'
  ),

  -- ── Pillar 4: Real estate & fit-out ──────────────────────────────────────
  -- Rent % of revenue — NRA published guideline.
  (
    'rent_pct_of_revenue', NULL,
    'range', NULL, NULL, NULL, 6, 10, NULL,
    'https://restaurant.org/research-and-media/research/industry-statistics/',
    'National Restaurant Association — Industry Statistics',
    '2024-01-01', '2026-06-07', 'high', '2026.Q2',
    'NRA published rent-to-revenue guideline for food-service operators.'
  ),
  -- Rent per sqft — trade-press composite across US metros.
  (
    'rent_per_sqft_annual_usd', NULL,
    'range', NULL, NULL, NULL, 30, 100, NULL,
    'https://dailycoffeenews.com/category/business/',
    'Daily Coffee News — Lease coverage composite',
    '2024-01-01', '2026-06-07', 'medium', '2026.Q2',
    'Annual rent per sqft for retail coffee leases; low end = mid-market suburban strip, high end = top-50-metro urban storefront.'
  ),
  -- Fit-out per sqft — trade-press operator profiles.
  (
    'fitout_per_sqft_usd', NULL,
    'range', NULL, NULL, NULL, 250, 450, NULL,
    'https://dailycoffeenews.com/category/business/',
    'Daily Coffee News — Operator build cost composite',
    '2024-01-01', '2026-06-07', 'high', '2026.Q2',
    'Turnkey specialty cafe fit-out cost per built sqft (excludes major MEP / structural upgrades).'
  )
ON CONFLICT (metric_id, cohort_id, source_url, extraction_date) DO UPDATE SET
  low = EXCLUDED.low,
  high = EXCLUDED.high,
  p25 = EXCLUDED.p25,
  p50 = EXCLUDED.p50,
  p75 = EXCLUDED.p75,
  source_name = EXCLUDED.source_name,
  source_publication_date = EXCLUDED.source_publication_date,
  extraction_confidence = EXCLUDED.extraction_confidence,
  dataset_version = EXCLUDED.dataset_version,
  notes = EXCLUDED.notes;
-- TIM-2447: Seed benchmark_best_practices.
--
-- Curated, well-known industry guidelines that don't need AI extraction —
-- they're stable rules-of-thumb published by SCA / NCA / NRA / academic
-- sources and used across the industry. Phase 0 ships these so that even if
-- the AI-extraction pipeline returns no cohort rows for a given metric, the
-- Phase 1 engine still has a guideline to fall back to.
--
-- Idempotent: composite unique on (metric_id, applicable_cohort_filter,
-- source_url, extraction_date). Re-runs on the same day overwrite.
--
-- Dataset version stamped to 2026.Q2; quarterly refresh re-stamps.

INSERT INTO public.benchmark_best_practices (
  metric_id, applicable_cohort_filter, guideline_low, guideline_high, guideline_target,
  rationale, source_url, source_name, source_publication_date, dataset_version
) VALUES
  -- Labor % — SCA Operators Guide is the canonical reference.
  (
    'labor_pct_of_revenue',
    NULL,
    25, 30, 28,
    'SCA Operators Guide target: 25-30% labor cost for specialty coffee operators. Anything above 32% signals overstaffing or wage misalignment; anything below 23% signals understaffing risk to service quality.',
    'https://sca.coffee/research',
    'Specialty Coffee Association — Operators Guide',
    '2024-01-01',
    '2026.Q2'
  ),
  (
    'labor_pct_of_revenue',
    '{"model":"drive_thru"}'::jsonb,
    22, 27, 25,
    'Drive-thru shops typically run 2-3 points below the cafe baseline because dine-in service labor is removed. SCA Operators Guide drive-thru annex / NRA QSR labor benchmarks.',
    'https://sca.coffee/research',
    'Specialty Coffee Association — Operators Guide (drive-thru annex)',
    '2024-01-01',
    '2026.Q2'
  ),

  -- COGS % — NCA + NRA give a tight target range for specialty operators.
  (
    'total_cogs_pct',
    NULL,
    28, 35, 32,
    'NCA / NRA target for total COGS in a specialty coffee operation: 28-35%. The bottom of the range is achievable with vertical milk sourcing and tight portion control; the top is the upper limit before margin compression becomes structural.',
    'https://www.ncausa.org/Industry-Resources',
    'National Coffee Association — Industry Resources',
    '2024-01-01',
    '2026.Q2'
  ),
  (
    'beverage_cogs_pct',
    NULL,
    18, 25, 22,
    'Beverage-only COGS for specialty espresso: 18-25%. Milk is the largest variable; concentrated cold brew and oat-milk premiums push toward the upper bound.',
    'https://www.ncausa.org/Industry-Resources',
    'National Coffee Association — Industry Resources',
    '2024-01-01',
    '2026.Q2'
  ),

  -- Rent — NRA published guideline is widely cited.
  (
    'rent_pct_of_revenue',
    NULL,
    6, 10, 8,
    'NRA published guideline for food-service rent-to-revenue: 6-10%. Above 10% pressures margin; below 6% usually indicates either a B/C location or a long-tenured below-market lease.',
    'https://restaurant.org/research-and-media/research/industry-statistics/',
    'National Restaurant Association — Industry Statistics',
    '2024-01-01',
    '2026.Q2'
  ),

  -- Fit-out per sqft — Daily Coffee News / specialty trade press cite this band.
  (
    'fitout_per_sqft_usd',
    NULL,
    250, 450, 350,
    'Specialty cafe fit-out: $250-$450 per sqft for a turnkey build (no major MEP / structural surprises). Drive-thru small format typically lands at the lower end; full dine-in cafe with bakery / kitchen at the upper end.',
    'https://dailycoffeenews.com/category/business/',
    'Daily Coffee News — Business',
    '2024-01-01',
    '2026.Q2'
  ),

  -- Turnover — NRA broad benchmark for limited-service.
  (
    'turnover_pct_annual',
    NULL,
    60, 130, 90,
    'NRA limited-service turnover ranges from 60% (well-run, tipped, high-engagement) to 130% (industry-wide, including QSR). Specialty cafes that invest in training + benefits cluster at the lower end.',
    'https://restaurant.org/research-and-media/research/industry-statistics/',
    'National Restaurant Association — Industry Statistics',
    '2024-01-01',
    '2026.Q2'
  )
ON CONFLICT (metric_id, applicable_cohort_filter, source_url, extraction_date) DO UPDATE SET
  guideline_low = EXCLUDED.guideline_low,
  guideline_high = EXCLUDED.guideline_high,
  guideline_target = EXCLUDED.guideline_target,
  rationale = EXCLUDED.rationale,
  source_name = EXCLUDED.source_name,
  source_publication_date = EXCLUDED.source_publication_date,
  dataset_version = EXCLUDED.dataset_version;
